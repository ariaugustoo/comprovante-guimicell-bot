from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, ContextTypes, filters
from utils.processador import processar_comprovante
from utils.ocr import extrair_texto

async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    file = await update.message.document.get_file()
    file_path = "/tmp/" + update.message.document.file_name
    await file.download_to_drive(file_path)
    texto = extrair_texto(file_path)
    resultado = processar_comprovante(texto)
    resposta = f"🧾 Comprovante processado:

{resultado}" if resultado else "❌ Não foi possível identificar o comprovante."
    await update.message.reply_text(resposta)

app = ApplicationBuilder().token("YOUR_BOT_TOKEN").build()
app.add_handler(MessageHandler(filters.Document.ALL, handle_document))

if __name__ == "__main__":
    app.run_polling()