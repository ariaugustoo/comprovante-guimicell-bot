import re

def calcular_valor_liquido(texto):
    match = re.search(r"(R\$\s*|\b)(\d{1,3}(\.\d{3})*,\d{2})", texto)
    if not match:
        return "Valor não identificado."

    valor_bruto_str = match.group(2).replace('.', '').replace(',', '.')
    valor_bruto = float(valor_bruto_str)

    # Simulação de taxa para crédito parcelado (exemplo genérico)
    taxa = 0.035  # 3.5%
    valor_liquido = round(valor_bruto * (1 - taxa), 2)

    return f"💰 Valor bruto: R$ {valor_bruto:.2f}\n🔻 Taxa aplicada: {taxa*100:.1f}%\n✅ Valor a repassar: R$ {valor_liquido:.2f}"