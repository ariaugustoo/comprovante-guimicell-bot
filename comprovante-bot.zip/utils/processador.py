from .ocr import extrair_texto
from .pagamento import calcular_valor_liquido

def processar_comprovante(texto_extraido: str):
    if "guimicell" in texto_extraido.lower():
        return calcular_valor_liquido(texto_extraido)
    return None