import pytesseract
from pdf2image import convert_from_path
from PIL import Image

def extrair_texto(caminho_arquivo):
    if caminho_arquivo.lower().endswith(".pdf"):
        imagens = convert_from_path(caminho_arquivo)
        texto = ""
        for imagem in imagens:
            texto += pytesseract.image_to_string(imagem, lang='por')
        return texto
    elif caminho_arquivo.lower().endswith((".png", ".jpg", ".jpeg")):
        imagem = Image.open(caminho_arquivo)
        return pytesseract.image_to_string(imagem, lang='por')
    return ""